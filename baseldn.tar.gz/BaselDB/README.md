DB consisting of:
- All proteins from Basel collection with known function
- 50 randomly chosen proteins from:
    - E. coli
    - B. subtilis
    - S. cerevisiae
    - M. musculus
    - H. sapiens
    - D. melanogaster